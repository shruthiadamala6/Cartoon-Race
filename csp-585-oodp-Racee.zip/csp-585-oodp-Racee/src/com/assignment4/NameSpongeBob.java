package com.assignment4;

public class NameSpongeBob implements Name{

	public String getName(){

		return "SpongeBob";
	}
}
