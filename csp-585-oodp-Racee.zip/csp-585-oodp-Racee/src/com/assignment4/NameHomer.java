package com.assignment4;

public class NameHomer implements Name{

	public String getName(){

		return "Homer";
	}
}
