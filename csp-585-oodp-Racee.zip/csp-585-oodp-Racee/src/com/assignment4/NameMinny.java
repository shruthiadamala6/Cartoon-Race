package com.assignment4;

public class NameMinny implements Name{

	public String getName(){

		return "Minny";
	}
}
