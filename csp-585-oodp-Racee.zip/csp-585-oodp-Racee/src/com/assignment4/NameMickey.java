package com.assignment4;

public class NameMickey implements Name{

	public String getName(){

		return "Mickey";
	}
}
