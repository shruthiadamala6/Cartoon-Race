package com.assignment4;

public class NameGoofy implements Name{

	public String getName(){
		
		return "Goofy";
	}
}
