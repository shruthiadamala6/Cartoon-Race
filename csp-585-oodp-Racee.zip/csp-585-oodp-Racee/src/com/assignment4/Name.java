package com.assignment4;

public interface Name {

	String getName();
}
